﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 叶文龙1800012425圆
{
    public partial class Form1 : Form
    {
        bool Flag = false; //圆心选择判断
        int columns = 60, rows = 40; //60列，40行
        Point center;  //圆心

        public Form1()
        {
            InitializeComponent();
        }

        //画网格
        private void Grid()
        {
            Graphics g = pictureBox1.CreateGraphics();
            Pen pen = new Pen(Brushes.Black);
            int size1 = pictureBox1.Width / columns;
            int size2 = pictureBox1.Height / rows;

            for (int x = 0; x < pictureBox1.Width; x += size1)
            {
                g.DrawLine(pen, new Point(x, 0), new Point(x, pictureBox1.Height));
            }
            for (int y = 0; y < pictureBox1.Height; y += size2)
            {
                g.DrawLine(pen, new Point(0, y), new Point(pictureBox1.Width, y));
            }
        }

        //单点填充
        private void plot(Point p)
        {
            int size1 = pictureBox1.Width / columns;
            int size2 = pictureBox1.Height / rows;

            Graphics g = pictureBox1.CreateGraphics();
            g.FillRectangle(new SolidBrush(Color.LightCoral),new Rectangle(p.X * size1, p.Y * size2, size1, size2));
        }

        //画圆八点对称处理填充绘制
        private void circle_plot8(int x,int y)
        {
            plot(new Point(x+center.X, y+center.Y));
            plot(new Point(-x+center.X, y+center.Y));
            plot(new Point(x+center.X, -y+center.Y));
            plot(new Point(-x+center.X, -y+center.Y));
            plot(new Point(y+center.X, x+center.Y));
            plot(new Point(-y+center.X, x+center.Y));
            plot(new Point(y+center.X, -x+center.Y));
            plot(new Point(-y+center.X, -x+center.Y));
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if(Flag)
            {
                //鼠标位置（圆心）在网格上坐标表示
                float size1 = pictureBox1.Width / columns;
                float size2 = pictureBox1.Height / rows;
                float x = e.X/size1;
                float y = e.Y/size2;

                center.X = columns * e.X / pictureBox1.Width;
                center.Y = rows * e.Y / pictureBox1.Height;

                plot(center);

                label2.Text = "(" + x.ToString() + "," + y.ToString() + ")";

                //置零判定
                Flag=false;
            }
        }

        //画网格
        private void button1_Click(object sender, EventArgs e)
        {
            Grid();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Flag = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //读取半径
            int radius = Convert.ToInt32(textBox1.Text);

            //半径超过网格范围时，在右上角报错
            if (radius > center.X || radius > center.Y||center.X+radius>=columns||center.Y+radius>=rows) label3.Text = "提示：半径过大";

            //圆大小在网格容纳范围内
            else
            {
                //绘圆
                int x = 0, y = radius;
                int d = 3 - 2 * radius;
                while (x < y)
                {
                    circle_plot8(x, y);
                    if (d < 0)
                    {
                        d = d + 4 * x + 6;
                    }
                    else
                    {
                        d = d + 4 * (x - y) + 10;
                        --y;
                    }
                    ++x;
                    if (x == y) circle_plot8(x, y);
                }
                Grid();
                label3.Text = "提示：";
            }
        }

        //清空
        private void button5_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();
            g.Clear(Color.White);
            Grid();
        }
    }
}
