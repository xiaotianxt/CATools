﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 计算机图形学基础_HW1
{
    public partial class Form1 : Form
    {
        bool Flag1 = false, Flag2 = false;   //判断起点与终点
        int columns = 60, rows = 40;   //60列，40行
        Point start, end;   //起点与终点

        public Form1()
        {
            InitializeComponent();
        }

        //画格网
        private void Grid()
        {
            Graphics g = pictureBox1.CreateGraphics();
            Pen pen = new Pen(Brushes.Black);

            //网格大小设置
            int size1 = pictureBox1.Width / columns;
            int size2 = pictureBox1.Height / rows;

            //网格绘制
            for (int x = 0; x < pictureBox1.Width; x += size1)
            {
                g.DrawLine(pen, new Point(x, 0), new Point(x, pictureBox1.Height));
            }
            for (int y = 0; y < pictureBox1.Height; y += size2)
            {
                g.DrawLine(pen, new Point(0, y), new Point(pictureBox1.Width, y));
            }
        }

        //填充网络
        private void plot(Point p)
        {
            int size1 = pictureBox1.Width / columns;
            int size2 = pictureBox1.Height / rows;

            Graphics g = pictureBox1.CreateGraphics();
            g.FillRectangle(new SolidBrush(Color.LightCoral),new Rectangle(p.X * size1, p.Y * size2, size1, size2));
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            //起点
            if(Flag1&&!Flag2)
            {
                //鼠标位置在网格上的表达
                float size1 = pictureBox1.Width / columns;
                float size2 = pictureBox1.Height / rows;
                float x = e.X/size1;
                float y = e.Y/size2;

                //起点缺点
                start.X = columns * e.X / pictureBox1.Width;
                start.Y = rows * e.Y / pictureBox1.Height;

                plot(start);

                //显示坐标
                label2.Text = "(" + x.ToString() + "," + y.ToString() + ")";

                //置零标准
                Flag1=false;
            }

            //终点
            else if (!Flag1 && Flag2)
            {
                //基本同起点
                float size1 = pictureBox1.Width / columns;
                float size2 = pictureBox1.Height / rows;
                float x = e.X / size1;
                float y = e.Y / size2;

                end.X = columns * e.X / pictureBox1.Width;
                end.Y = rows * e.Y / pictureBox1.Height;

                plot(end);

                label4.Text = "(" + x.ToString() + "," + y.ToString() + ")";

                Flag2=false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Grid();
        }

        //选择起点
        private void button2_Click(object sender, EventArgs e)
        {
            Flag1 = true;
            Flag2 = false;
        }

        //选择终点
        private void button3_Click(object sender, EventArgs e)
        {
            Flag2 = true;
            Flag1 = false;
        }

        //绘制直线
        private void button4_Click(object sender, EventArgs e)
        {
            int x = start.X, y = start.Y;
            int s1, s2,temp,interchange,f;
            int deltax = Math.Abs(end.X - x), deltay = Math.Abs(end.Y - y);
            if (end.X-x>=0)
                s1 = 1;
            else
                s1 = -1;

            if (end.Y - y >= 0)
                s2 = 1;
            else
                s2 = -1;

            if (deltay > deltax)
            {
                temp = deltax;
                deltax = deltay;
                deltay = temp;
                interchange = 1;
            }
            else
                interchange = 0;

            f = 2 * deltay - deltax;

            for(int i=1;i<=deltax+1;++i)
            {
                plot(new Point(x, y));
                if (f>=0)
                {
                    if (interchange == 1)
                        x += s1;
                    else
                        y += s2;
                    f -= 2 * deltax;
                }
                if (interchange == 1)
                    y += s2;
                else
                    x += s1;
                f += 2 * deltay;
            }
            Grid();
        }

        //清空
        private void button5_Click(object sender, EventArgs e)
        {
            Graphics g = pictureBox1.CreateGraphics();
            g.Clear(Color.White);
            Grid();
        }
    }
}
