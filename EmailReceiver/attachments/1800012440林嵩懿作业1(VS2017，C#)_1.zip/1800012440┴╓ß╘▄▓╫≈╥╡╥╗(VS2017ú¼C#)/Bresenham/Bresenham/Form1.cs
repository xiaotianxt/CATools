﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Bresenham
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private bool IsLine = true;//true表示正在直线算法,false表示正在圆形算法
        private bool selectbegin = false, selectend = false, selectfinished = false;
        private bool sel_b_finished = false, sel_e_finished = false;//分别表示起始点是否选择
        private bool selectcenter = false;
        private bool sel_c_finished = false;//表示圆心是否选择
        private Point MousePoint;
        private Point BeginPoint;
        private Point EndPoint;
        private MyLine Line;
        private MyCircle Circle;
        private Point CenterPoint;
        //绘制网格线
        private void drawGrids(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen myPen = Pens.Black;
            int lineWidth = this.pictureBox1.Width / 10 * 10, lineHeight = this.pictureBox1.Height / 10 * 10;
            for (int i = 0; i <= lineWidth;)
            {
                g.DrawLine(myPen, new Point(i, 0), new Point(i, lineHeight));
                i += 10;
            }

            for (int j = 0; j <= lineHeight;)
            {
                g.DrawLine(myPen, new Point(0, j), new Point(lineWidth, j));
                j += 10;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(IsLine)
            {
                selectbegin = true;
                selectend = false;
                selectfinished = false;
            }
            else
            {
                selectcenter = true;
                selectfinished = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(IsLine)
            {
                selectbegin = false;
                selectend = true;
                selectfinished = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(IsLine)
            {
                selectbegin = false;
                selectend = false;
                selectfinished = true;
                if (sel_b_finished && sel_e_finished)
                {
                    Line = new MyLine(BeginPoint, EndPoint);
                    sel_b_finished = false;
                    sel_e_finished = false;
                }
                pictureBox1.Refresh();
            }
            else
            {
                selectcenter = false;
                selectfinished = true;
                if(sel_c_finished)
                {
                    int r0 = Convert.ToInt32(textBox2.Text);
                    Circle = new MyCircle(CenterPoint,r0*10);
                }
                pictureBox1.Refresh();
            }
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            MousePoint = new Point(e.Location.X / 10 * 10, e.Location.Y / 10 * 10);
            pictureBox1.Refresh();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            selectbegin = false;
            selectend = false;
            selectfinished = false;
            sel_b_finished = false;
            sel_e_finished = false;
            selectcenter = false;
            sel_c_finished = false;
            pictureBox1.Refresh();
            IsLine = true;
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            IsLine = false;
            selectbegin = false;
            selectend = false;
            selectfinished = false;
            sel_b_finished = false;
            sel_e_finished = false;
            selectcenter = false;
            sel_c_finished = false;
            pictureBox1.Refresh();
            textBox1.Text = "";
            textBox2.Text = "请在此处输入半径(整数,错误输入会报错)";
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if(IsLine)
            {
                if (selectbegin)
                {
                    BeginPoint = MousePoint;
                    sel_b_finished = true;
                    pictureBox1.Refresh();
                    textBox1.Text = "起点：" + Convert.ToString(BeginPoint.X / 10) + "," + Convert.ToString(BeginPoint.Y / 10);
                }
                else if (selectend)
                {
                    EndPoint = MousePoint;
                    sel_e_finished = true;
                    pictureBox1.Refresh();
                    textBox2.Text = "终点：" + Convert.ToString(EndPoint.X / 10) + "," + Convert.ToString(EndPoint.Y / 10);
                }
            }
            else
            {
                if(selectcenter)
                {
                    CenterPoint = MousePoint;
                    sel_c_finished = true;
                    pictureBox1.Refresh();
                    textBox1.Text = "圆心：" + Convert.ToString(CenterPoint.X / 10) + "," + Convert.ToString(CenterPoint.Y / 10);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(IsLine)
            {
                selectbegin = false;
                selectend = false;
                selectfinished = false;
                sel_b_finished = false;
                sel_e_finished = false;
                pictureBox1.Refresh();
                textBox1.Text = "";
                textBox2.Text = "";
            }
            else
            {
                selectcenter = false;
                sel_c_finished = false;
                selectfinished = false;
                pictureBox1.Refresh();
                textBox1.Text = "";
                textBox2.Text = "请在此处输入半径(整数,错误输入会报错)";
            }
        }

        //画布作画
        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            drawGrids(e);//每次作画先画网格
            Graphics g = e.Graphics;
            g.FillRectangle(new SolidBrush(Color.FromArgb(122, 122, 122)), MousePoint.X, MousePoint.Y, 10, 10);
            if(IsLine)
            {
                if (selectfinished)
                {
                    Line.DrawLine(e, Color.FromArgb(255, 0, 0));
                }
                if (sel_b_finished)
                {
                    g.FillRectangle(new SolidBrush(Color.FromArgb(255, 0, 0)), BeginPoint.X, BeginPoint.Y, 10, 10);
                }
                if (sel_e_finished)
                {
                    g.FillRectangle(new SolidBrush(Color.FromArgb(255, 0, 0)), EndPoint.X, EndPoint.Y, 10, 10);
                }
            }
            else
            {
                if(selectfinished)
                {
                    Circle.DrawCircle(e, Color.FromArgb(255, 0, 0));
                }
                if (sel_c_finished)
                {
                    g.FillRectangle(new SolidBrush(Color.FromArgb(255, 0, 0)), CenterPoint.X, CenterPoint.Y, 10, 10);
                }
            }
        }

        
    }
}
