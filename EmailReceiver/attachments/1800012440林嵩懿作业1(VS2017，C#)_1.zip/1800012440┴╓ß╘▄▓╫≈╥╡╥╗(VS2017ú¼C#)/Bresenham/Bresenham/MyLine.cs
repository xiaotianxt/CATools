﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Bresenham
{
    class MyLine
    {
        public Point BeginNode;
        public Point EndNode;
        public MyLine(Point p1,Point p2)
        {
            BeginNode = p1;
            EndNode = p2;
        }
        public void DrawLine(PaintEventArgs e, Color color)
        {
            Graphics g = e.Graphics;
            int deltax;
            int deltay;
            int x = BeginNode.X;
            int y = BeginNode.Y;
            int s1, s2, interchange;
            if((EndNode.X - BeginNode.X)>=0)
            {
                s1 = 10;
                deltax = EndNode.X - BeginNode.X;
            }
            else
            {
                s1 = -10;
                deltax = BeginNode.X - EndNode.X;
            }
            if((EndNode.Y - BeginNode.Y) >= 0)
            {
                s2 = 10;
                deltay = EndNode.Y - BeginNode.Y;
            }
            else
            {
                s2 = -10;
                deltay = BeginNode.Y - EndNode.Y;
            }
            if(deltay>deltax)
            {
                int temp = deltax;
                deltax = deltay;
                deltay = temp;
                interchange = 1;
            }
            else
            {
                interchange = 0;
            }
            int f = 2 * deltay - deltax;
            for(int i=0;i<=deltax;i+=10)
            {
                g.FillRectangle(new SolidBrush(color), new Rectangle(x, y, 10, 10));
                if(f>=0)
                {
                    if(interchange==1)
                    {
                        x += s1;
                    }
                    else
                    {
                        y += s2;
                    }
                    f -= 2 * deltax;
                }
                if(interchange==1)
                {
                    y += s2;
                }
                else
                {
                    x += s1;
                }
                f += 2 * deltay;
            }
        }
    }
}
