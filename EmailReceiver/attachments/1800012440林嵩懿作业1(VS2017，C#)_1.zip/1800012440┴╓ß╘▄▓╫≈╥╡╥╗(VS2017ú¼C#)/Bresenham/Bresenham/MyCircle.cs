﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Bresenham
{
    class MyCircle
    {
        public Point Center;
        public int Radius;
        public MyCircle(Point p)
        {
            Center = p;
            Radius = 0;
        }
        public MyCircle(Point p,int r)
        {
            Center = p;
            Radius = r;
        }
        public void DrawCircle(PaintEventArgs e, Color color)
        {
            Graphics g = e.Graphics;
            //绘制圆心
            g.FillRectangle(new SolidBrush(color), new Rectangle(Center, new Size(10, 10)));
            if (Radius == 0)
                return;
            int x = 0, y = Radius, d = 3 - 2 * Radius / 10;
            while (x < y)
            {
                g.FillRectangle(new SolidBrush(color), new Rectangle(Center.X + x, Center.Y + y, 10, 10));
                g.FillRectangle(new SolidBrush(color), new Rectangle(Center.X + y, Center.Y + x, 10, 10));
                g.FillRectangle(new SolidBrush(color), new Rectangle(Center.X - x, Center.Y + y, 10, 10));
                g.FillRectangle(new SolidBrush(color), new Rectangle(Center.X + y, Center.Y - x, 10, 10));
                g.FillRectangle(new SolidBrush(color), new Rectangle(Center.X + x, Center.Y - y, 10, 10));
                g.FillRectangle(new SolidBrush(color), new Rectangle(Center.X - y, Center.Y + x, 10, 10));
                g.FillRectangle(new SolidBrush(color), new Rectangle(Center.X - x, Center.Y - y, 10, 10));
                g.FillRectangle(new SolidBrush(color), new Rectangle(Center.X - y, Center.Y - x, 10, 10));
                if (d < 0)
                    d = d + 4 * x / 10 + 6;
                else
                {
                    d = d + 4 * (x - y) / 10 + 10;
                    y = y - 10;
                }
                x += 10;
            }
            if (x == y)
            {
                g.FillRectangle(new SolidBrush(color), new Rectangle(Center.X + x, Center.Y + y, 10, 10));
                g.FillRectangle(new SolidBrush(color), new Rectangle(Center.X - x, Center.Y + y, 10, 10));
                g.FillRectangle(new SolidBrush(color), new Rectangle(Center.X + x, Center.Y - y, 10, 10));
                g.FillRectangle(new SolidBrush(color), new Rectangle(Center.X - x, Center.Y - y, 10, 10));
            }
        }
    }
}
