﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace arc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            grid = new Bitmap(this.pictureBox1.Width, this.pictureBox1.Height);
            this.pictureBox1.Image = grid;
            Graphics g = Graphics.FromImage(grid);
            Draw_grid(g);
            
        }
        
        Bitmap grid;
        int x, y, xx, yy, R, d, temp_x, temp_y;

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("选择网格中一点作为圆心，在左侧文本框中输入半径，点击生成圆即可。\n\n若要重新选择参数，请点击重置按钮。");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            grid = new Bitmap(this.pictureBox1.Width, this.pictureBox1.Height);
            this.pictureBox1.Image = grid;
            Graphics g = Graphics.FromImage(grid);
            Draw_grid(g);
            label1.Text = "None";
            textBox1.Text = "0";
            x = 0;
            y = 0;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                R = Convert.ToInt32(textBox1.Text);
                if (R == 0)
                {
                    MessageBox.Show("圆的半径不能为0！");
                    return;
                }
                xx = x;
                yy = y;
                if (xx == 0 || yy == 0) 
                {
                    MessageBox.Show("请选择圆心！");
                    return;
                }
                x = 0;
                y = R;
                d = 3 - 2 * R;
                SolidBrush mySolidBrush = new SolidBrush(Color.Red);
                Graphics myGraphics = this.pictureBox1.CreateGraphics();

                while (x < y)
                {
                    temp_x = xx + x * 10;
                    temp_y = yy + y * 10;
                    myGraphics.FillRectangle(mySolidBrush, xx + x * 10, yy + y * 10, 9, 9);
                    myGraphics.FillRectangle(mySolidBrush, xx + y * 10, yy + x * 10, 9, 9);
                    myGraphics.FillRectangle(mySolidBrush, xx - x * 10, yy + y * 10, 9, 9);
                    myGraphics.FillRectangle(mySolidBrush, xx - y * 10, yy + x * 10, 9, 9);
                    myGraphics.FillRectangle(mySolidBrush, xx + x * 10, yy - y * 10, 9, 9);
                    myGraphics.FillRectangle(mySolidBrush, xx + y * 10, yy - x * 10, 9, 9);
                    myGraphics.FillRectangle(mySolidBrush, xx - x * 10, yy - y * 10, 9, 9);
                    myGraphics.FillRectangle(mySolidBrush, xx - y * 10, yy - x * 10, 9, 9);
                    if (d < 0)
                        d = d + 4 * x + 6;
                    else
                    {
                        d = d + 4 * (x - y) + 10;
                        y = y - 1;
                    }
                    x = x + 1;
                }
                if (x == y)
                {
                    myGraphics.FillRectangle(mySolidBrush, xx + x * 10, yy + y * 10, 9, 9);
                    myGraphics.FillRectangle(mySolidBrush, xx + y * 10, yy + x * 10, 9, 9);
                    myGraphics.FillRectangle(mySolidBrush, xx - x * 10, yy + y * 10, 9, 9);
                    myGraphics.FillRectangle(mySolidBrush, xx - y * 10, yy + x * 10, 9, 9);
                    myGraphics.FillRectangle(mySolidBrush, xx + x * 10, yy - y * 10, 9, 9);
                    myGraphics.FillRectangle(mySolidBrush, xx + y * 10, yy - x * 10, 9, 9);
                    myGraphics.FillRectangle(mySolidBrush, xx - x * 10, yy - y * 10, 9, 9);
                    myGraphics.FillRectangle(mySolidBrush, xx - y * 10, yy - x * 10, 9, 9);
                }
                x = 0;
                y = 0;
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
               
                if (label1.Text == "None")
                {
                    x = e.X;
                    y = e.Y;
                    x = x - x % 10 + 1;
                    y = y - y % 10 + 1;
                    SolidBrush mySolidBrush = new SolidBrush(Color.Red);
                    Graphics myGraphics = this.pictureBox1.CreateGraphics();
                    label1.Text = ((x - 1) / 10 + "," + (y - 1) / 10);
                    myGraphics.FillRectangle(mySolidBrush, x, y, 9, 9);
                }
                else
                {
                    MessageBox.Show("你只能选择一个点作为圆心！\n\n点击重置按钮可重新选择。");
                }
            }
            
        }

        public void Draw_grid(Graphics g)
        {
            Pen myPen = new Pen(Color.Black, (float)1);
            //垂直
            for (int i = 0; i < this.pictureBox1.Width; i += 10)
            {
                g.DrawLine(myPen, new Point(i, 0), new Point(i, this.pictureBox1.Height - 1));
            }
            //水平
            for (int j = 0; j < this.pictureBox1.Height; j += 10)
            {
                g.DrawLine(myPen, new Point(0, j), new Point(this.pictureBox1.Width - 1, j));
            }
        }
        
    }
}
