﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace line
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            grid = new Bitmap(this.pictureBox1.Width, this.pictureBox1.Height);
            this.pictureBox1.Image = grid;
            Graphics g = Graphics.FromImage(grid);
            Draw_grid(g);
            x1 = 0;
            x2 = 0;
            y1 = 0;
            y2 = 0;

        }

        Bitmap grid;
        int x, y, x1, y1, x2, y2;
        int xx, yy, dx, dy, s1, s2, temp, interchange, f, i;

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("鼠标选择网格中的两个点作为直线端点，单击生成线即可。\n\n若要重新选择，请点击重置按钮。");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (x1 == 0 || x2 == 0 || y1 == 0 || y2 == 0)
                {
                    MessageBox.Show("选择两个端点后，才能生成直线！");
                    return;
                }
                xx = x1;
                yy = y1;
                dx = System.Math.Abs(x2 - x1) / 10;
                dy = System.Math.Abs(y2 - y1) / 10;
                if (x2 - x1 >= 0)
                    s1 = 10;
                else
                    s1 = -10;
                if (y2 - y1 >= 0)
                    s2 = 10;
                else
                    s2 = -10;
                if (dy > dx)
                {
                    temp = dx;
                    dx = dy;
                    dy = temp;
                    interchange = 1;
                }
                else
                    interchange = 0;
                f = 2 * dy - dx;
                for (i = 1; i <= dx + 1; i++)
                {
                    SolidBrush mySolidBrush = new SolidBrush(Color.Red);
                    Graphics myGraphics = this.pictureBox1.CreateGraphics();
                    myGraphics.FillRectangle(mySolidBrush, xx, yy, 9, 9);
                    if (f >= 0)
                    {
                        if (interchange == 1)
                            xx = xx + s1;
                        else
                            yy = yy + s2;
                        f = f - 2 * dx;
                    }
                    if (interchange == 1)
                        yy = yy + s2;
                    else
                        xx = xx + s1;
                    f = f + 2 * dy;
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            return;
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                //获取鼠标点下的位置
                x = e.X;
                y = e.Y;
                x = x - x % 10 + 1;
                y = y - y % 10 + 1;
                SolidBrush mySolidBrush = new SolidBrush(Color.Red);
                Graphics myGraphics = this.pictureBox1.CreateGraphics();

                if (label1.Text == "None")
                {
                    x1 = x;
                    y1 = y;
                    label1.Text = ((x - 1) / 10 + "," + (y - 1) / 10);
                    myGraphics.FillRectangle(mySolidBrush, x, y, 9, 9);
                }
                else if (label2.Text == "None")
                {
                    x2 = x;
                    y2 = y;
                    label2.Text = ((x - 1) / 10 + "," + (y - 1) / 10);
                    myGraphics.FillRectangle(mySolidBrush, x, y, 9, 9);
                }
                else
                {
                    MessageBox.Show("你最多只能选择两个端点！\n单击鼠标右键可取消选择的点");
                }
                
            }
            /*if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                x = e.X;
                y = e.Y;
                x = x - x % 10 + 1;
                y = y - y % 10 + 1;
                SolidBrush mySolidBrush = new SolidBrush(Color.White);
                Graphics myGraphics = this.pictureBox1.CreateGraphics();
                if (label2.Text != "None")
                {
                    myGraphics.FillRectangle(mySolidBrush, x2, y2, 9, 9);
                    label2.Text = "None";
                }
                else
                {
                    myGraphics.FillRectangle(mySolidBrush, x1, y1, 9, 9);
                    label1.Text = "None";
                }
            }*/
        }
        
        public void Draw_grid(Graphics g)
        {
            Pen myPen = new Pen(Color.Black, (float)1);
            //垂直
            for (int i = 0; i < this.pictureBox1.Width; i += 10)
            {
                g.DrawLine(myPen, new Point(i, 0), new Point(i, this.pictureBox1.Height - 1));
            }
            //水平
            for (int j = 0; j < this.pictureBox1.Height; j += 10)
            {
                g.DrawLine(myPen, new Point(0, j), new Point(this.pictureBox1.Width - 1, j));
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            grid = new Bitmap(this.pictureBox1.Width, this.pictureBox1.Height);
            this.pictureBox1.Image = grid;
            Graphics g = Graphics.FromImage(grid);
            Draw_grid(g);
            label1.Text = "None";
            label2.Text = "None";
            x1 = 0;
            x2 = 0;
            y1 = 0;
            y2 = 0;
        }
    }
}
